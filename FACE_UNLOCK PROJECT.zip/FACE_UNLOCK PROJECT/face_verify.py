#import required libraries
from deepface.basemodels import Facenet
from deepface.commons import functions
import numpy as np
import faiss
#!pip install playsound==1.2.2
from playsound import playsound
import threading

#load the index for neighbor search
index=faiss.read_index("vector1.index")

#load facenet
model=Facenet.loadModel()

#function for face recognition
def predict_face(path):
    #extract face and return in the form of pixel values
    img=functions.preprocess_face(img=path,target_size=(160,160),enforce_detection=False)
    #return embedded vector for image
    embedding_vector=model.predict(img)[0,:]
    #convert embedding_vector to numpy array
    embedding_vector=np.array(embedding_vector).astype("float32")
    #expand the dimension(convert image to 2D)
    embedding_vector=np.expand_dims(embedding_vector,axis=0)
    #Finding Best Match
    distance,_=index.search(embedding_vector,1)
    
    #condition for getting name from the face
    if distance[0][0]<35:
        name="lakshmi"
    else:
        name="Mis-Match"
        # threading.Thread(target=playsound,args=("emergency-alert.mp3",)).start()
        
    #return name
    return name