#importing required libraries
from face_verify import predict_face
import cv2
from fastapi import FastAPI


#capturing the video using webcam
cap = cv2.VideoCapture(0)

#Fastapi instance
app = FastAPI()

#importing haar cascade file
face_cascade=cv2.CascadeClassifier(cv2.data.haarcascades+"haarcascade_frontalface_default.xml")
@app.get('/')
def home():
    return 'Welcome to face unlock application'

@app.post('/predict')
def predict():


    while True:
        #extracting frames from video
        _,frame = cap.read()
    
        #converting frames into gray scale frame for detecting face
        gray_img = cv2.cvtColor(frame,cv2.COLOR_BGR2GRAY)
        #detect faces using haar cascade file imported
        detect_faces=face_cascade.detectMultiScale(gray_img,scaleFactor=1.3,minNeighbors=3) 
    
        #taking name from the face
        name=predict_face(frame)
        #draw rectangle and text in frame
        for (x,y,w,h) in detect_faces:
            cv2.rectangle(frame,pt1=(x,y),pt2=(x+w,y+h),color=(0,255,0),thickness=2)
            cv2.putText(frame,text=name,org=(x,y),fontFace=cv2.FONT_ITALIC,fontScale=2,color=(255,0,0),thickness=3)
    
        #display the frame until "q" keyword is pressed
        cv2.imshow("Frame",frame)
        if cv2.waitKey(1) & 0xFF==ord("q"):
            break

    #release the webcam and destroy all windows
    cap.release()
    cv2.destroyAllWindows()
    